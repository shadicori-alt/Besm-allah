// نظام إدارة التواصل الذكي - الملف الرئيسي
// Smart Communication Management System - Main File

// ============================================================================
// إعدادات النظام العامة
// ============================================================================

class SmartSystem {
    constructor() {
        this.currentUser = null;
        this.settings = {};
        this.isOnline = navigator.onLine;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSettings();
        this.initializeServices();
        this.setupOfflineSupport();
    }

    setupEventListeners() {
        // مراقبة حالة الاتصال
        window.addEventListener('online', () => {
            this.isOnline = true;
            this.showNotification('تم استعادة الاتصال بالإنترنت', 'success');
            this.syncData();
        });

        window.addEventListener('offline', () => {
            this.isOnline = false;
            this.showNotification('النظام يعمل في وضع عدم الاتصال', 'warning');
        });

        // مراقبة تغييرات الصفحة
        document.addEventListener('DOMContentLoaded', () => {
            this.initializePage();
        });
    }

    loadSettings() {
        const savedSettings = localStorage.getItem('smartSystemSettings');
        if (savedSettings) {
            this.settings = JSON.parse(savedSettings);
        } else {
            this.settings = this.getDefaultSettings();
            this.saveSettings();
        }
    }

    getDefaultSettings() {
        return {
            theme: 'light',
            language: 'ar',
            notifications: true,
            autoSync: true,
            aiModel: 'openai',
            responseSpeed: 5,
            soundEnabled: true,
            showTooltips: true
        };
    }

    saveSettings() {
        localStorage.setItem('smartSystemSettings', JSON.stringify(this.settings));
    }

    initializeServices() {
        // تهيئة الخدمات الأساسية
        this.database = new LocalDatabase();
        this.apiHandler = new APIHandler();
        this.uiManager = new UIManager();
        this.chatAssistant = new ChatAssistant();
        this.aiEngine = new AIEngine();
    }

    setupOfflineSupport() {
        // إعداد العمل دون اتصال
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js')
                .then(registration => console.log('SW registered'))
                .catch(error => console.log('SW registration failed'));
        }
    }

    initializePage() {
        // تهيئة الصفحة الحالية
        const currentPage = window.location.pathname.split('/').pop() || 'index';
        
        // إزالة الامتداد .html إذا وجد
        const pageName = currentPage.replace('.html', '');
        
        // استدعاء منشئ الصفحة المناسب
        if (this[`init${pageName.charAt(0).toUpperCase() + pageName.slice(1)}Page`]) {
            this[`init${pageName.charAt(0).toUpperCase() + pageName.slice(1)}Page`]();
        }

        // تهيئة العناصر المشتركة
        this.initializeCommonElements();
    }

    initializeCommonElements() {
        // تهيئة المساعد الذكي
        this.chatAssistant.initialize();
        
        // إضافة تأثيرات الرسوم المتحركة
        this.addAnimations();
        
        // إعداد أزرار الشرح
        this.setupHelpButtons();
    }

    addAnimations() {
        // إضافة تأثيرات CSS
        const style = document.createElement('style');
        style.textContent = `
            .fade-in { animation: fadeIn 0.5s ease-in; }
            .slide-up { animation: slideUp 0.3s ease-out; }
            .pulse { animation: pulse 2s infinite; }
            
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            @keyframes slideUp {
                from { transform: translateY(20px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
            
            @keyframes pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.05); }
            }
        `;
        document.head.appendChild(style);
    }

    setupHelpButtons() {
        // إضافة أزرار الشرح للصفحات
        const helpButtons = document.querySelectorAll('[data-help]');
        helpButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const page = e.target.dataset.help;
                this.chatAssistant.explainPage(page);
            });
        });
    }

    showNotification(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${this.getNotificationClass(type)}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // إضافة تأثير الظهور
        setTimeout(() => notification.classList.add('fade-in'), 100);
        
        // إزالة الإشعار بعد المدة المحددة
        setTimeout(() => {
            notification.classList.remove('fade-in');
            setTimeout(() => document.body.removeChild(notification), 300);
        }, duration);
    }

    getNotificationClass(type) {
        const classes = {
            success: 'bg-green-500 text-white',
            error: 'bg-red-500 text-white',
            warning: 'bg-yellow-500 text-black',
            info: 'bg-blue-500 text-white'
        };
        return classes[type] || classes.info;
    }

    syncData() {
        if (this.isOnline && this.settings.autoSync) {
            this.database.syncWithServer();
            this.showNotification('تمت مزامنة البيانات بنجاح', 'success');
        }
    }
}

// ============================================================================
// قاعدة البيانات المحلية
// ============================================================================

class LocalDatabase {
    constructor() {
        this.dbName = 'SmartSystemDB';
        this.version = 1;
        this.db = null;
        this.init();
    }

    init() {
        const request = indexedDB.open(this.dbName, this.version);
        
        request.onerror = (event) => {
            console.error('فشل فتح قاعدة البيانات:', event.target.error);
        };

        request.onsuccess = (event) => {
            this.db = event.target.result;
            console.log('تم فتح قاعدة البيانات بنجاح');
        };

        request.onupgradeneeded = (event) => {
            this.db = event.target.result;
            this.createStores();
        };
    }

    createStores() {
        // إنشاء متاجر البيانات
        const stores = [
            { name: 'orders', key: 'id', autoIncrement: true },
            { name: 'agents', key: 'id', autoIncrement: true },
            { name: 'products', key: 'id', autoIncrement: true },
            { name: 'customers', key: 'id', autoIncrement: true },
            { name: 'settings', key: 'key' },
            { name: 'chatHistory', key: 'id', autoIncrement: true },
            { name: 'notifications', key: 'id', autoIncrement: true }
        ];

        stores.forEach(store => {
            if (!this.db.objectStoreNames.contains(store.name)) {
                const objectStore = this.db.createObjectStore(store.name, {
                    keyPath: store.key,
                    autoIncrement: store.autoIncrement
                });
                
                // إنشاء الفهارس
                if (store.name === 'orders') {
                    objectStore.createIndex('status', 'status', { unique: false });
                    objectStore.createIndex('date', 'date', { unique: false });
                    objectStore.createIndex('agent', 'agent', { unique: false });
                }
                
                if (store.name === 'products') {
                    objectStore.createIndex('category', 'category', { unique: false });
                    objectStore.createIndex('price', 'price', { unique: false });
                }
            }
        });
    }

    // عمليات CRUD عامة
    async save(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.put(data);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async get(storeName, key) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.get(key);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAll(storeName, index = null, value = null) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            let request;
            
            if (index && value) {
                request = store.index(index).getAll(value);
            } else {
                request = store.getAll();
            }
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async delete(storeName, key) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.delete(key);
            
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async syncWithServer() {
        // محاكاة مزامنة مع الخادم
        console.log('جاري مزامنة البيانات مع الخادم...');
        
        // في الواقع، هنا سيتم إرسال البيانات المحلية إلى الخادم
        // والحصول على التحديثات الجديدة
        
        return new Promise(resolve => {
            setTimeout(() => {
                console.log('اكتملت المزامنة');
                resolve();
            }, 2000);
        });
    }
}

// ============================================================================
// معالج API
// ============================================================================

class APIHandler {
    constructor() {
        this.baseURL = 'https://api.smart-system.com'; // URL افتراضي
        this.shopifyDomain = 'free-move-eg.myshopify.com';
        this.timeout = 10000; // 10 ثواني
    }

    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            timeout: this.timeout
        };

        try {
            const response = await fetch(url, config);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('فشل الطلب:', error);
            throw error;
        }
    }

    // Shopify API
    async fetchProducts() {
        try {
            // محاكاة جلب المنتجات من Shopify
            const mockProducts = [
                {
                    id: 1,
                    title: "منتج تجريبي 1",
                    price: 99.99,
                    inventory_quantity: 10,
                    image: "https://via.placeholder.com/200",
                    description: "وصف المنتج التجريبي"
                },
                {
                    id: 2,
                    title: "منتج تجريبي 2",
                    price: 149.99,
                    inventory_quantity: 5,
                    image: "https://via.placeholder.com/200",
                    description: "وصف آخر للمنتج"
                }
            ];

            return mockProducts;
        } catch (error) {
            console.error('فشل جلب المنتجات:', error);
            return [];
        }
    }

    async fetchOrders() {
        // محاكاة جلب الطلبات
        return [
            {
                id: 1001,
                customer: "أحمد محمد",
                status: "new",
                total: 299.99,
                date: new Date().toISOString(),
                agent: null
            },
            {
                id: 1002,
                customer: "سارة أحمد",
                status: "assigned",
                total: 149.99,
                date: new Date().toISOString(),
                agent: "محمد"
            }
        ];
    }

    async fetchAgents() {
        // محاكاة جلب المناديب
        return [
            {
                id: 1,
                name: "محمد علي",
                status: "active",
                ordersCount: 5,
                rating: 4.8,
                phone: "+201234567890"
            },
            {
                id: 2,
                name: "سارة أحمد",
                status: "busy",
                ordersCount: 3,
                rating: 4.9,
                phone: "+201234567891"
            }
        ];
    }

    async updateOrderStatus(orderId, status, agentId = null) {
        // محاكاة تحديث حالة الطلب
        return {
            success: true,
            orderId: orderId,
            newStatus: status,
            assignedAgent: agentId
        };
    }
}

// ============================================================================
// مدير واجهة المستخدم
// ============================================================================

class UIManager {
    constructor() {
        this.activeAnimations = new Set();
    }

    showNotification(message, type = 'info', duration = 3000) {
        if (window.smartSystem) {
            window.smartSystem.showNotification(message, type, duration);
        }
    }

    updateDashboard(data) {
        // تحديث عناصر لوحة التحكم
        this.updateStatsCards(data.stats);
        this.updateServiceStatus(data.services);
        this.updateRecentActivity(data.recent);
    }

    updateStatsCards(stats) {
        const cards = document.querySelectorAll('.stats-card');
        cards.forEach((card, index) => {
            if (stats[index]) {
                const valueElement = card.querySelector('.stats-value');
                if (valueElement) {
                    this.animateNumber(valueElement, stats[index].value);
                }
            }
        });
    }

    animateNumber(element, targetNumber) {
        const duration = 1000;
        const start = parseInt(element.textContent) || 0;
        const increment = (targetNumber - start) / (duration / 16);
        let current = start;

        const timer = setInterval(() => {
            current += increment;
            if (current >= targetNumber) {
                current = targetNumber;
                clearInterval(timer);
            }
            element.textContent = Math.floor(current);
        }, 16);
    }

    showLoading(element) {
        element.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحميل...';
        element.disabled = true;
    }

    hideLoading(element, originalText) {
        element.innerHTML = originalText;
        element.disabled = false;
    }

    createModal(content, options = {}) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold">${options.title || 'تنبيه'}</h3>
                    <button class="close-modal text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-content">
                    ${content}
                </div>
                <div class="flex justify-end space-x-2 mt-4">
                    ${options.showCancel ? '<button class="cancel-btn bg-gray-500 text-white px-4 py-2 rounded">إلغاء</button>' : ''}
                    <button class="confirm-btn bg-blue-500 text-white px-4 py-2 rounded">${options.confirmText || 'موافق'}</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // إضافة معالجات الأحداث
        modal.querySelector('.close-modal').addEventListener('click', () => {
            this.closeModal(modal);
        });

        if (options.showCancel) {
            modal.querySelector('.cancel-btn').addEventListener('click', () => {
                this.closeModal(modal);
                if (options.onCancel) options.onCancel();
            });
        }

        modal.querySelector('.confirm-btn').addEventListener('click', () => {
            if (options.onConfirm) options.onConfirm();
            this.closeModal(modal);
        });

        // إغلاق عند النقر خارج النافذة
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.closeModal(modal);
            }
        });

        return modal;
    }

    closeModal(modal) {
        document.body.removeChild(modal);
    }
}

// ============================================================================
// المساعد الذكي
// ============================================================================

class ChatAssistant {
    constructor() {
        this.isOpen = false;
        this.chatHistory = [];
        this.currentContext = {};
        this.suggestions = [
            "أظهر لي الطلبات الجديدة",
            "كم عدد المناديب النشطين؟",
            "أنشئ تقرير المبيعات",
            "ابحث عن منتج معين",
            "أرسل تنبيه للمندوبين"
        ];
    }

    initialize() {
        this.createChatInterface();
        this.loadChatHistory();
        this.setupEventListeners();
    }

    createChatInterface() {
        // إنشاء واجهة الدردشة إذا لم تكن موجودة
        if (!document.getElementById('chatAssistant')) {
            const chatHTML = `
                <div id="chatAssistant" class="fixed bottom-4 left-4 z-50">
                    <!-- زر المساعد -->
                    <div id="chatButton" class="assistant-button bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white p-4 rounded-full shadow-lg cursor-pointer transition-all duration-300">
                        <div class="flex flex-col items-center">
                            <i class="fas fa-robot text-xl mb-1"></i>
                            <span class="text-xs font-bold">مساعدك الذكي</span>
                        </div>
                        <div id="notificationBadge" class="notification-badge hidden"></div>
                    </div>
                    
                    <!-- نافذة الدردشة -->
                    <div id="chatWindow" class="chat-window hidden bg-white rounded-lg shadow-xl w-96 h-96 flex flex-col">
                        <!-- رأس الدردشة -->
                        <div class="chat-header bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-t-lg">
                            <div class="flex justify-between items-center">
                                <div class="flex items-center">
                                    <i class="fas fa-robot mr-2"></i>
                                    <div>
                                        <h3 class="font-bold">المساعد الذكي</h3>
                                        <span class="text-xs opacity-75 online-status">متصل الآن</span>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <button id="minimizeChat" class="text-white hover:text-gray-200">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                    <button id="closeChat" class="text-white hover:text-gray-200">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- منطقة الرسائل -->
                        <div id="chatMessages" class="chat-messages flex-1 p-4 overflow-y-auto">
                            <div class="welcome-message bg-gray-100 p-3 rounded-lg mb-3">
                                <p class="text-sm">مرحباً! كيف يمكنني مساعدتك اليوم؟</p>
                                <div class="typing-indicator hidden mt-2">
                                    <span class="typing-dot"></span>
                                    <span class="typing-dot"></span>
                                    <span class="typing-dot"></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- الاقتراحات السريعة -->
                        <div id="quickSuggestions" class="quick-suggestions p-2 border-t bg-gray-50">
                            <div class="flex flex-wrap gap-1">
                                ${this.suggestions.map(suggestion => 
                                    `<button class="suggestion-btn bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs hover:bg-blue-200 transition-colors">${suggestion}</button>`
                                ).join('')}
                            </div>
                        </div>
                        
                        <!-- إدخال الرسائل -->
                        <div class="chat-input p-4 border-t">
                            <div class="flex items-center space-x-2">
                                <input type="text" id="chatInput" placeholder="اكتب سؤالك هنا..." 
                                       class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <button id="sendMessage" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', chatHTML);
        }
    }

    setupEventListeners() {
        // زر فتح/إغلاق الدردشة
        document.getElementById('chatButton').addEventListener('click', () => {
            this.toggleChat();
        });

        // أزرار التحكم
        document.getElementById('closeChat').addEventListener('click', () => {
            this.closeChat();
        });

        document.getElementById('minimizeChat').addEventListener('click', () => {
            this.minimizeChat();
        });

        // إرسال الرسائل
        document.getElementById('sendMessage').addEventListener('click', () => {
            this.sendMessage();
        });

        document.getElementById('chatInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });

        // الاقتراحات السريعة
        document.querySelectorAll('.suggestion-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const message = e.target.textContent;
                document.getElementById('chatInput').value = message;
                this.sendMessage();
            });
        });
    }

    toggleChat() {
        const chatWindow = document.getElementById('chatWindow');
        const chatButton = document.getElementById('chatButton');
        
        if (this.isOpen) {
            chatWindow.classList.add('hidden');
            chatButton.classList.remove('hidden');
        } else {
            chatWindow.classList.remove('hidden');
            chatButton.classList.add('hidden');
            document.getElementById('chatInput').focus();
        }
        
        this.isOpen = !this.isOpen;
        this.hideNotificationBadge();
    }

    closeChat() {
        const chatWindow = document.getElementById('chatWindow');
        const chatButton = document.getElementById('chatButton');
        
        chatWindow.classList.add('hidden');
        chatButton.classList.remove('hidden');
        this.isOpen = false;
    }

    minimizeChat() {
        const chatWindow = document.getElementById('chatWindow');
        chatWindow.classList.add('minimized');
    }

    async sendMessage() {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();
        
        if (!message) return;
        
        // إضافة رسالة المستخدم
        this.addMessage(message, 'user');
        input.value = '';
        
        // إظهار مؤشر الكتابة
        this.showTypingIndicator();
        
        try {
            // معالجة الرسالة باستخدام الذكاء الاصطناعي
            const response = await this.aiEngine.generateResponse(message, this.currentContext);
            
            // إخفاء مؤشر الكتابة
            this.hideTypingIndicator();
            
            // إضافة رد المساعد
            this.addMessage(response.text, 'assistant');
            
            // تنفيذ أي إجراءات مطلوبة
            if (response.action) {
                this.executeAction(response.action);
            }
            
        } catch (error) {
            console.error('خطأ في معالجة الرسالة:', error);
            this.hideTypingIndicator();
            this.addMessage('عذراً، حدث خطأ في معالجة طلبك. حاول مرة أخرى.', 'assistant');
        }
    }

    addMessage(text, sender) {
        const messagesContainer = document.getElementById('chatMessages');
        const messageElement = document.createElement('div');
        
        const className = sender === 'user' ? 'user-message bg-blue-100 ml-12' : 'bot-message bg-gray-100 mr-12';
        const alignment = sender === 'user' ? 'text-left' : 'text-right';
        
        messageElement.className = `message ${className} p-3 rounded-lg mb-2 ${alignment}`;
        messageElement.innerHTML = `
            <p class="text-sm">${text}</p>
            <span class="text-xs text-gray-500">${new Date().toLocaleTimeString('ar-EG')}</span>
        `;
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // حفظ في التاريخ
        this.chatHistory.push({
            text: text,
            sender: sender,
            timestamp: new Date()
        });
        
        this.saveChatHistory();
    }

    showTypingIndicator() {
        const indicator = document.querySelector('.typing-indicator');
        indicator.classList.remove('hidden');
        
        const messagesContainer = document.getElementById('chatMessages');
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    hideTypingIndicator() {
        const indicator = document.querySelector('.typing-indicator');
        indicator.classList.add('hidden');
    }

    async executeAction(action) {
        switch (action.type) {
            case 'navigate':
                window.location.href = action.data.url;
                break;
                
            case 'updateOrder':
                await this.updateOrderStatus(action.data.orderId, action.data.status);
                break;
                
            case 'assignAgent':
                await this.assignAgentToOrder(action.data.orderId, action.data.agentId);
                break;
                
            case 'generateReport':
                await this.generateReport(action.data.reportType);
                break;
                
            case 'searchProduct':
                const products = await this.searchProducts(action.data.query);
                this.displaySearchResults(products);
                break;
                
            default:
                console.log('نوع إجراء غير معروف:', action.type);
        }
    }

    showNotificationBadge() {
        const badge = document.getElementById('notificationBadge');
        badge.classList.remove('hidden');
        badge.classList.add('pulse');
    }

    hideNotificationBadge() {
        const badge = document.getElementById('notificationBadge');
        badge.classList.add('hidden');
        badge.classList.remove('pulse');
    }

    loadChatHistory() {
        const saved = localStorage.getItem('chatHistory');
        if (saved) {
            this.chatHistory = JSON.parse(saved);
        }
    }

    saveChatHistory() {
        localStorage.setItem('chatHistory', JSON.stringify(this.chatHistory));
    }

    explainPage(pageName) {
        const explanations = {
            'dashboard': 'لوحة التحكم الرئيسية تعرض نظرة عامة على جميع أنشطة شركتك. يمكنك مشاهدة إحصائيات الطلبات، حالة الخدمات، والوصول السريع للوظائف المهمة.',
            'orders': 'صفحة إدارة الطلبات تتيح لك متابعة جميع الطلبات من لحظة استلامها حتى التسليم. يمكنك تغيير الحالات، تعيين المناديب، وطباعة الفواتير.',
            'agents': 'إدارة المناديب تشمل متابعة أداء كل مندوب، تعيين المهام، حساب العمولات، ومراقبة نشاطهم اليومي.',
            'ai': 'إعدادات الذكاء الاصطناعي تسمح لك باختيار نموذج الردود، تخصيص الإجابات، واختبار أداء النظام قبل التفعيل.'
        };
        
        const explanation = explanations[pageName] || 'صفحة غير معروفة';
        this.addMessage(explanation, 'assistant');
    }
}

// ============================================================================
// محرك الذكاء الاصطناعي
// ============================================================================

class AIEngine {
    constructor() {
        this.models = {
            openai: 'gpt-3.5-turbo',
            deepseek: 'deepseek-chat'
        };
        this.currentModel = 'openai';
        this.context = {};
        this.knowledgeBase = this.initializeKnowledgeBase();
    }

    initializeKnowledgeBase() {
        return {
            // قاعدة معرفية بالمحاسبة
            accounting: {
                'حساب الربح': 'الربح = الإيرادات - المصروفات - التكاليف',
                'العمولة': 'عمولة المندوب = (قيمة الطلب × نسبة العمولة) / 100',
                'الضرائب': 'الضريبة = صافي الربح × نسبة الضريبة',
                'التكاليف الثابتة': 'تشمل الإيجار، الرواتب، الكهرباء، المياه',
                'التكاليف المتغيرة': 'تشمل تكلفة المنتجات، الشحن، العمولات'
            },
            
            // قاعدة معرفية بالإدارة
            management: {
                'تقييم الأداء': 'يعتمد على عدد الطلبات، وقت التسليم، رضا العملاء',
                'توزيع المهام': 'حسب الموقع الجغرافي، حمولة العمل، الكفاءة',
                'إدارة المخزون': 'مستوى إعادة الطلب = (معدل الاستهلاك × فترة التوريد) + مخزون أمان',
                'جودة الخدمة': 'تقاس بسرعة الاستجابة، دقة الطلبات، تعامل العملاء'
            },
            
            // معلومات الشركة
            company: {
                'عنوان': 'https://free-move-eg.myshopify.com',
                'ساعات العمل': 'من 9 صباحاً حتى 10 مساءً',
                'سياسة الإرجاع': 'يمكن إرجاع المنتج خلال 14 يوم مع الحفاظ على حالته الأصلية',
                'الشحن': 'التوصيل خلال 1-3 أيام عمل حسب الموقع'
            }
        };
    }

    async generateResponse(message, context = {}) {
        // تحليل نية الرسالة
        const intent = this.analyzeIntent(message);
        
        // توليد الرد المناسب
        let response = await this.generateAppropriateResponse(message, intent, context);
        
        // إذا كانت هناك إجراءات مطلوبة
        const action = this.determineAction(message, intent);
        
        return {
            text: response,
            action: action,
            intent: intent,
            confidence: 0.85 // نسبة الثقة في التحليل
        };
    }

    analyzeIntent(message) {
        const lowerMessage = message.toLowerCase();
        
        // تحليل النية بناءً على الكلمات المفتاحية
        if (lowerMessage.includes('طلب') || lowerMessage.includes('أوردر')) {
            return 'order_inquiry';
        }
        
        if (lowerMessage.includes('مندوب') || lowerMessage.includes('موظف')) {
            return 'agent_inquiry';
        }
        
        if (lowerMessage.includes('سعر') || lowerMessage.includes('منتج')) {
            return 'product_inquiry';
        }
        
        if (lowerMessage.includes('تقرير') || lowerMessage.includes('تحليل')) {
            return 'report_request';
        }
        
        if (lowerMessage.includes('حساب') || lowerMessage.includes('مبلغ')) {
            return 'accounting_inquiry';
        }
        
        if (lowerMessage.includes('تغيير') || lowerMessage.includes('تحديث')) {
            return 'update_request';
        }
        
        return 'general_inquiry';
    }

    async generateAppropriateResponse(message, intent, context) {
        switch (intent) {
            case 'order_inquiry':
                return this.handleOrderInquiry(message);
                
            case 'agent_inquiry':
                return this.handleAgentInquiry(message);
                
            case 'product_inquiry':
                return this.handleProductInquiry(message);
                
            case 'report_request':
                return this.handleReportRequest(message);
                
            case 'accounting_inquiry':
                return this.handleAccountingInquiry(message);
                
            case 'update_request':
                return this.handleUpdateRequest(message);
                
            default:
                return this.handleGeneralInquiry(message);
        }
    }

    handleOrderInquiry(message) {
        if (message.includes('جديد')) {
            return 'سأعرض لك الطلبات الجديدة. هل تريد عرضها جميعاً أم حسب تاريخ معين؟';
        }
        
        if (message.includes('حالة')) {
            return 'يمكنني مساعدتك في تغيير حالة طلب معين. الرجاء تزويدي برقم الطلب والحالة الجديدة المطلوبة.';
        }
        
        return 'أنا هنا للمساعدة في إدارة الطلبات. يمكنني عرض الطلبات، تغيير الحالات، أو تعيينها للمناديب. ماذا تحتاج؟';
    }

    handleAgentInquiry(message) {
        if (message.includes('أداء')) {
            return 'سأقوم بتحليل أداء المناديب وعرض الإحصائيات. هل تريد تقريراً شاملأً أم لمناديب محددين؟';
        }
        
        if (message.includes('تعيين')) {
            return 'يمكنني مساعدتك في تعيين طلب لمندوب معين. أرسل لي رقم الطلب واسم المندوب.';
        }
        
        return 'لدي معلومات كاملة عن المناديب: الأداء، عدد الطلبات، التقييمات. ما الذي تحتاج معرفته؟';
    }

    handleProductInquiry(message) {
        return 'سأبحث لك عن المنتجات. هل لديك اسم المنتج أو الفئة المطلوبة؟ يمكنني أيضاً عرض جميع المنتجات المتوفرة.';
    }

    handleReportRequest(message) {
        if (message.includes('مبيعات')) {
            return 'سأنشئ لك تقرير المبيعات. هل تريده يومياً، أسبوعياً، أم شهرياً؟';
        }
        
        if (message.includes('مناديب')) {
            return 'سأقوم بإنشاء تقرير شامل عن أداء المناديب مع جميع الإحصائيات المهمة.';
        }
        
        return 'يمكنني إنشاء تقارير متنوعة: مبيعات، أداء المناديب، رضا العملاء. أي نوع من التقارير تحتاج؟';
    }

    handleAccountingInquiry(message) {
        if (message.includes('ربح')) {
            return `حساب الربح = الإيرادات - المصروفات - التكاليف. هل تريدني أن أحسب الربح لفترة معينة؟`;
        }
        
        if (message.includes('عمولة')) {
            return 'عمولة المندوب = (قيمة الطلب × نسبة العمولة) / 100. يمكنني حساب العمولات لجميع المناديب.';
        }
        
        return 'لدي معرفة واسعة بالمحاسبة والإدارة. يمكنني مساعدتك في الحسابات، التحليلات المالية، وإدارة التكاليف.';
    }

    handleUpdateRequest(message) {
        return 'يمكنني مساعدتك في تحديث البيانات. الرجاء تحديد ما الذي تريد تحديثه: طلب، مندوب، منتج، أم إعدادات النظام؟';
    }

    handleGeneralInquiry(message) {
        const responses = [
            'أنا مساعدك الذكي المتخصص في إدارة الأعمال. يمكنني مساعدتك في الطلبات، المناديب، المنتجات، والتقارير. ماذا تحتاج؟',
            'كيف يمكنني مساعدتك اليوم؟ لدي القدرة على إدارة الطلبات، متابعة المناديب، وإنشاء التقارير.',
            'مرحباً! أنا هنا لأجعل عملك أسهل. يمكنني مساعدتك في جميع جوانب إدارة شركتك.'
        ];
        
        return responses[Math.floor(Math.random() * responses.length)];
    }

    determineAction(message, intent) {
        // تحديد الإجراء المطلوب بناءً على النية
        switch (intent) {
            case 'order_inquiry':
                if (message.includes('أظهر')) {
                    return { type: 'showOrders', data: {} };
                }
                break;
                
            case 'report_request':
                return { type: 'generateReport', data: { reportType: 'general' } };
                
            case 'product_inquiry':
                const query = this.extractProductQuery(message);
                return { type: 'searchProduct', data: { query: query } };
                
            default:
                return null;
        }
        
        return null;
    }

    extractProductQuery(message) {
        // استخراج كلمات البحث عن المنتج
        const words = message.split(' ');
        const keywords = ['منتج', 'سعر', 'ابحث', 'أظهر', 'عرض'];
        return words.filter(word => !keywords.includes(word)).join(' ');
    }

    learnFromInteraction(message, response, feedback) {
        // تعلم من التفاعلات لتحسين الأداء
        this.context.lastInteraction = {
            message: message,
            response: response,
            feedback: feedback,
            timestamp: new Date()
        };
        
        // حفظ في قاعدة البيانات للتعلم المستقبلي
        this.saveLearningData();
    }

    saveLearningData() {
        const learningData = {
            context: this.context,
            knowledgeBase: this.knowledgeBase,
            timestamp: new Date()
        };
        
        localStorage.setItem('aiLearningData', JSON.stringify(learningData));
    }
}

// ============================================================================
// تهيئة النظام
// ============================================================================

// إنشاء نسخة عالمية من النظام
window.smartSystem = new SmartSystem();

// دالة مساعدة للوصول السريع للمساعد
window.askAssistant = function(message) {
    if (window.smartSystem && window.smartSystem.chatAssistant) {
        window.smartSystem.chatAssistant.toggleChat();
        setTimeout(() => {
            document.getElementById('chatInput').value = message;
            window.smartSystem.chatAssistant.sendMessage();
        }, 500);
    }
};

// دالة شرح الصفحة
window.explainPage = function() {
    const pageName = document.title || 'هذه الصفحة';
    askAssistant(`اشرح لي وظائف ${pageName}`);
};

console.log('✅ تم تحميل نظام إدارة التواصل الذكي بنجاح');